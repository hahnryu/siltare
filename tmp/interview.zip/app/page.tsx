import { InterviewScreen } from "@/components/interview/interview-screen"

export default function Page() {
  return <InterviewScreen />
}
