import { IntervieweeLanding } from "@/components/interviewee-landing"

export default function Page() {
  return <IntervieweeLanding />
}
