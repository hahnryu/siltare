import { InterviewScreen } from "@/components/interview/interview-screen"

export default function InterviewPage() {
  return <InterviewScreen />
}
