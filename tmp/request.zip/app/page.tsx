import { SiltareForm } from "@/components/siltare/siltare-form"

export default function Page() {
  return <SiltareForm />
}
